function showMessage() {
  alert("Oh! You just clicked the button.");
}
